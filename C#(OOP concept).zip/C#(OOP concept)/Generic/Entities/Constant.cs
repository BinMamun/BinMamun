﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic.Entities
{
    public enum AnimalType
    {
        Harvivore = 1,
        Carvivore,
        Omnivore,

    }//AnimalType enum

    public enum Gender
    {
        Male = 1,
        Female
    }//Gender enum

}//NameSpace
